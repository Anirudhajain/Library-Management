<?php
// including the database connection file
include_once("config.php");

 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    $student_name=$_POST['student_name'];
    $student_roll=$_POST['student_roll'];
    
    $book_name=$_POST['book_name'];
    $book_no=$_POST['book_no'];   

    $branch=$_POST['branch'];   
    $sem=$_POST['sem'];   
    $issuing_date=$_POST['issuing_date'];    
    
    // checking empty fields
    if(empty($student_roll) ||empty($book_name) || empty($student_name) || empty($book_no)|| empty($sem)|| empty($branch)|| empty($issuing_date)) {            
        if(empty($book_name)) {
            echo "<font color='red'> Book Name field is empty.</font><br/>";
        }
        
        if(empty($student_name)) {
            echo "<font color='red'>Stdeunt Name field is empty.</font><br/>";
        }
        
        if(empty($book_no)) {
            echo "<font color='red'>Book No field is empty.</font><br/>";
        }   
        if(empty($branch)) {
            echo "<font color='red'>Branch field is empty.</font><br/>";
        }
        
        if(empty($sem)) {
            echo "<font color='red'>Semester field is empty.</font><br/>";
        }
 	 if(empty($issuing_date)) {
            echo "<font color='red'>Issuing Date field is empty.</font><br/>";
        }  
	if(empty($student_roll)) {
            echo "<font color='red'>Student Roll No field is empty.</font><br/>";
        }          
    } else {    
        //updating the table
        $result = mysqli_query($mysqli, "UPDATE books_issue SET student_roll='$student_roll',book_name='$book_name',student_name='$student_name',book_no='$book_no',branch='$branch' 
	,sem='$sem' ,issuing_date='$issuing_date'  WHERE id=$id");
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: issued_books.php");
    }
}
?>
<?php
//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM books_issue WHERE id=$id");
 
while($res = mysqli_fetch_array($result))
{
    $book_name = $res['book_name'];
  $student_roll = $res['student_roll'];
    $student_name = $res['student_name'];
    $book_no = $res['book_no'];
     $sem = $res['sem'];
    $branch = $res['branch'];
    $issuing_date = $res['issuing_date'];
}
?>
<html>
<head>    
    <title>Update Book Issue Details</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>
 
<body>
   <br><br>
<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="wellcome.php">Back</a>
 <a href="#"><h3 align="center"><b>Book Details Updates</b></h3><a/>
</nav>
<br><br>
    <br/><br/>
    
    <form name="form1" method="post" action="issue_update.php">
        <table  class="table">
   <tr>
    <td> 1.Student Roll No. </td>
    <td><input type="text" name="student_roll" required value="<?php echo $student_roll;?>"></td>
   </tr>
   
   <tr>
    <td> 2.Book Name </td>
    <td><input type="text" name="book_name" required value="<?php echo $book_name;?>"></td>
   </tr>
   <tr>
    <td>3.Student Name</td>
    <td><input type="text" name="student_name" required value="<?php echo $student_name;?>"></td>
   </tr> 
   <tr>
    <td>4.Book No.</td>
    <td><input type="text" name="book_no" required value="<?php echo $book_no;?>"></td>
   </tr>
   <tr>
    <td>5.Branch</td>
    <td><input type="text" name="branch" required  value="<?php echo $branch;?>"></td>
   </tr>
   <tr>
    <td>6.Semester</td>
    <td><input type="text" name="sem" required value="<?php echo $sem;?>"></td>
   </tr> 
   <tr>
    <td>7.Adding Date</td>
    <td><input type="date" name="issuing_date" required value="<?php echo $issuing_date;?>"></td>
   </tr> 
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td><td></td>
            </tr>
	<tr>
	<td><input type="submit"  name="update" value="Update" class="btn btn-primary"></td><td></td>

	</tr>
        </table>
    </form>
</body>
</html>