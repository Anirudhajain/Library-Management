<?php
/*
// mysql_connect("database-host", "username", "password")
$conn = mysql_connect("localhost","id9861525_lib","123456") 
            or die("cannot connected");
 
// mysql_select_db("database-name", "connection-link-identifier")
@mysql_select_db("id9861525_lib",$conn);
*/
 
/**
 * mysql_connect is deprecated
 * using mysqli_connect instead
 */
 
$databaseHost = 'localhost';
$databaseName = 'id9861525_lib';
$databaseUsername = 'id9861525_lib';
$databasePassword = '123456';
 
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
?>