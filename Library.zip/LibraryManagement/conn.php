<?php

$con = mysqli_connect('localhost','id9861525_lib','123456');

mysqli_select_db($con,'id9861525_lib');

?>