<?php
// including the database connection file
include_once("config.php");

 
if(isset($_POST['update']))
{    
    $id = $_POST['id'];
    
    $book_name=$_POST['book_name'];
    $author_name=$_POST['author_name'];
    $book_no=$_POST['book_no'];   

    $branch=$_POST['branch'];   
    $sem=$_POST['sem'];   
    $adding_date=$_POST['adding_date'];    
    
    // checking empty fields
    if(empty($book_name) || empty($author_name) || empty($book_no)|| empty($sem)|| empty($branch)|| empty($adding_date)) {            
        if(empty($book_name)) {
            echo "<font color='red'>Book Name field is empty.</font><br/>";
        }
        
        if(empty($author_name)) {
            echo "<font color='red'>Author Name field is empty.</font><br/>";
        }
        
        if(empty($book_no)) {
            echo "<font color='red'>Book No field is empty.</font><br/>";
        }   
        if(empty($branch)) {
            echo "<font color='red'>Branch field is empty.</font><br/>";
        }
        
        if(empty($sem)) {
            echo "<font color='red'>Semester field is empty.</font><br/>";
        }
 	 if(empty($adding_date)) {
            echo "<font color='red'>Date field is empty.</font><br/>";
        }          
    } else {    
        //updating the table
        $result = mysqli_query($mysqli, "UPDATE books_detail SET book_name='$book_name',author_name='$author_name',book_no='$book_no',branch='$branch' 
	,sem='$sem' ,adding_date='$adding_date'  WHERE id=$id");
        
        //redirectig to the display page. In our case, it is index.php
        header("Location: wellcome.php");
    }
}
?>
<?php
//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM books_detail WHERE id=$id");
 
while($res = mysqli_fetch_array($result))
{
    $book_name = $res['book_name'];
    $author_name = $res['author_name'];
    $book_no = $res['book_no'];
     $sem = $res['sem'];
    $branch = $res['branch'];
    $adding_date = $res['adding_date'];
}
?>
<html>
<head>    
    <title>Update Book Details</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>
 
<body>
   <br><br>
<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="wellcome.php">Back</a>
 <a href="#"><h3 align="center"><b>Book Details Updates</b></h3><a/>
</nav>
<br><br>
    <br/><br/>
    
    <form name="form1" method="post" action="book_update.php">
        <table  class="table">
           <tr>
    <td> 1.Book Name </td>
    <td><input type="text" name="book_name" required value="<?php echo $book_name;?>"></td>
   </tr>
   <tr>
    <td>2.Author Name</td>
    <td><input type="text" name="author_name" required value="<?php echo $author_name;?>"></td>
   </tr> 
   <tr>
    <td>3.Book No.</td>
    <td><input type="text" name="book_no" required value="<?php echo $book_no;?>"></td>
   </tr>
   <tr>
    <td>4.Branch</td>
    <td><input type="text" name="branch" required value="<?php echo $branch;?>"></td>
   </tr>
   <tr>
    <td>5.Semester</td>
    <td><input type="text" name="sem" required value="<?php echo $sem;?>"></td>
   </tr> 
   <tr>
    <td>6.Adding Date</td>
    <td><input type="date" name="adding_date" required value="<?php echo $adding_date;?>"></td>
   </tr> 
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td><td></td>
            </tr>
	<tr>
	<td><input type="submit"  name="update" value="Update" class="btn btn-primary"></td><td></td>

	</tr>
        </table>
    </form>
</body>
</html>