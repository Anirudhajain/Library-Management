<?php

    $con=mysqli_connect('localhost','id9861525_lib','123456','id9861525_lib');

    if(!$con)
    {
        die(' Please Check Your Connection'.mysqli_error($con));
    }
?>